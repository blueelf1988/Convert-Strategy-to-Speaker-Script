---
name: global-brand-competitive-strategy
description: |
  Generate a global brand competitive strategy report for any brand. Use this skill for brand positioning, competitor analysis, global market opportunity assessment, market entry strategy, content strategy, channel strategy, product portfolio planning, conversion optimization, and team action alignment.

  Trigger this skill when the user asks for competitor analysis, global brand strategy, brand competitive strategy, market entry strategy, brand positioning, competitor breakdown, content and paid media observation, product page conversion diagnosis, homepage comparison, brand upgrade strategy, category strategy, or strategic action planning.

  Keyword triggers include: "competitive analysis", "competitor report", "global brand strategy", "brand competitive strategy", "brand positioning", "market entry", "content strategy", "conversion optimization", "global market differences", "how do we win", "how should this category be played", "break down this brand", "brand vs competitors", "homepage comparison", "product page audit", "market opportunity", "brand upgrade", "positioning map", "Excel competitor table", "scoring workbook", and similar requests.

  Output a complete single-file HTML report by default. The report should use a premium editorial competitive-intelligence style: full-screen hero, fixed glass navigation, large uppercase display typography, animated metrics, premium grid cards, evidence tables, 8D scoring heatmap, SVG positioning matrix, collapsible deep dives, score bar animation, GSAP scroll animation, evidence sources, action plan with priority rows, print support, and responsive layout.

  When the user asks for a spreadsheet, uploads an Excel template, or needs a structured competitor database, also generate an Excel companion workbook for competitor tracking, 8D scoring, evidence tracking, market comparison, positioning matrix data, content hooks, strategic trade-offs, and action planning.
license: MIT
metadata:
  version: "4.3.0"
  output_format: html
  optional_output_format: xlsx
  target_user: brand_team
  owner_role: global_brand_director
  visual_style: premium-editorial-competitive-intelligence-html
  html_interaction: gsap-scroll-collapsible
  excel_companion: optional
  excel_style: team-ready-competitive-strategy-workbook
  deep_dive: collapsible
  language_support: multilingual
---

# Global Brand Competitive Strategy Skill

Generate a structured global brand competitive strategy report for any brand, category, or market.

The core goal is to help the team answer:

> Which market should we prioritize, what positioning should we own, which competitors matter most, what differentiation should we build, what should we do first, and what should we avoid for now?

This skill should not produce a simple information summary. It should produce a decision-ready strategy report with clear recommendations, evidence levels, competitor scoring, positioning maps, content hooks, strategic trade-offs, and team actions.

---

## 1. Core Output

Every report must help the user make decisions across the following areas:

1. Brand positioning
2. Competitive landscape
3. Global market opportunity
4. Product and price strategy
5. Content and hook strategy
6. Channel strategy
7. Homepage and product page conversion
8. Brand asset and visual system
9. Strategic trade-offs
10. 30-day action plan

The final report must clearly answer:

```text
We should ______.
Because ______.
Do ______ first.
Do not do ______ for now.
```

---

## 2. Default Deliverables

### 2.1 Required Deliverable

By default, deliver:

1. A complete single-file HTML strategy report
2. One-sentence strategic conclusion
3. 8-dimension scoring heatmap
4. Global market difference table
5. Positioning matrix
6. Collapsible Deep Dive
7. Content & Hook System
8. Strategic Trade-Off table
9. 30-day Action Plan
10. Hold / Do Not Do list
11. Evidence Sources

### 2.2 Optional Deliverable

When requested, also deliver:

1. Excel companion workbook
2. Competitor database
3. Scoring table
4. Market comparison table
5. Positioning matrix data
6. Content hook library
7. Evidence source tracker
8. Action tracker

The HTML report is for management reading and strategic alignment.  
The Excel workbook is for team tracking, filtering, scoring, monthly updates, and execution management.

---

## 3. Usage Principles

### 3.1 Strategy First

The report must follow global brand competitive strategy logic. It must answer:

- What is the current competitive landscape?
- Where is the clearest opportunity?
- Who is the biggest threat?
- What should the brand prioritize?
- What should the brand avoid for now?
- How can the brand move from product/category thinking into clearer brand mindshare?

### 3.2 Evidence-Based Judgment

Do not present assumptions as facts. Label evidence quality clearly.

Use public sources, user-provided materials, uploaded files, official websites, marketplace pages, social platforms, review data, and credible industry sources where available.

If data is unavailable, state:

```text
No public evidence found.
```

If a conclusion is inferred, state:

```text
Inference based on available public signals.
```

### 3.3 Clear Strategic Position

Avoid generic conclusions such as:

```text
Each brand has its own strengths.
The brand should improve content quality.
The brand should strengthen brand building.
The market has large potential.
```

Use actionable conclusions such as:

```text
The brand should own ______ because competitors are over-indexing on ______.
The first priority is ______ because the conversion gap is currently in ______.
Do not copy ______ because it would weaken ______.
```

---

## 4. HTML Visual Output Standard

The HTML report must look like a premium competitive-intelligence editorial report, not a plain dashboard.

### 4.1 Visual Style Requirements

The report must include:

1. Full-screen Hero
2. Fixed glass navigation
3. Large uppercase editorial typography
4. Animated metrics
5. Premium grid cards
6. 8D scoring heatmap
7. SVG positioning matrix
8. Collapsible Deep Dive
9. Score bar animation
10. GSAP scroll animation
11. Evidence Sources
12. Action Plan with priority rows

### 4.2 Required HTML Sections

```text
1. Hero
   - Report name
   - Brand name
   - Category / scenario
   - 3–4 animated headline metrics

2. Executive Summary
   - Four strategic cards:
     01 Competitive Landscape
     02 Biggest Opportunity
     03 Biggest Threat
     04 30-Day Priority

3. Competitive Pool
   - 6–10 competitor cards
   - Subject brand highlighted
   - Competitor type badges
   - Price band
   - Reason included

4. Global Market Layer
   - Market difference table
   - Opportunity and risk by market

5. 8-Dimension Heatmap
   - Subject brand + competitors
   - 8 dimension scores
   - Overall score
   - Opportunity gap

6. Positioning Map
   - SVG matrix
   - Clearly labeled axes
   - Current brand position
   - Next recommended position

7. Brand Breakdown / Deep Dive
   - Collapsible cards
   - Subject brand open by default
   - Competitors collapsed by default
   - Score bars and detailed interpretation

8. Content & Hook System
   - Platform
   - Hook
   - Creative form
   - Funnel stage

9. Key Findings
   - Competitive landscape
   - Core opportunities
   - Biggest threats

10. Strategic Trade-Offs
   - What to learn
   - How to adapt
   - What not to copy

11. Action Plan
   - Priority
   - Team
   - Action
   - Owner
   - Deadline
   - Success metric

12. Evidence Sources
   - Source level
   - Source type
   - Notes

13. Footer
   - Data cutoff
   - Version
   - Built for Brand Team
```

### 4.3 Default Visual Tokens

Use the user brand color when available. If unavailable, use the following premium default:

```css
:root {
  --brand:       #574CD5;
  --brand-light: #EAE8FB;
  --brand-dark:  #3D34B0;
  --brand-dim:   rgba(87,76,213,0.12);
  --white:    #FFFFFF;
  --bg:       #FFFFFF;
  --bg-warm:  #F5F5F2;
  --bg-cool:  #EFEFEA;
  --ink:      #111111;
  --ink-2:    #444444;
  --ink-3:    #888888;
  --line:     #E2E2DE;
  --red:      #E03232;
  --green:    #1A8C4E;
  --amber:    #D97706;
  --font: 'Helvetica Neue', Helvetica, 'Noto Sans SC', 'PingFang SC','Microsoft YaHei', sans-serif;
  --radius: 2px;
}
```

### 4.4 Animation Requirements

Use GSAP when possible.

Required animations:

- Navigation slides in from top
- Hero title fades/slides in
- Hero metrics count up
- Summary cards animate on scroll
- Pool cards animate on scroll
- Deep Dive cards animate on scroll
- Action rows animate from left
- Score bars fill on scroll or on card expansion
- Optional subtle canvas background particle network

Do not over-animate. The style should feel premium and controlled.

### 4.5 Collapsible Deep Dive Interaction

Deep Dive cards must use native HTML `<details>`.

Requirements:

- Subject brand is open by default
- Competitors are collapsed by default
- Toggle text switches between:
  - `Click to Expand`
  - `Click to Collapse`
- Score bars animate when card opens
- Cards use left border color to indicate:
  - Subject brand
  - Threat competitor
  - Reference competitor

### 4.6 Brand Identifier Hygiene

Only include:

- The user’s brand name
- Competitor brand names
- Necessary report labels

Remove any template identifiers, example brand marks, or internal labels.

Do not leave placeholders such as:

```text
OV
OV Brand System
Built with OV Style System
Demo Brand
Sample Client
```

Use generic report identifiers such as:

```text
[Brand Name] Global Brand Strategy
[Brand Name] Competitive Strategy
[Brand Name] Global Brand Competitive Strategy
Built for Brand Team
```

---

## 5. Excel Workbook Output Standard

The Excel output is a **Competitive Strategy Workbook**, not a simple spreadsheet.

It should function as:

- Competitor database
- 8D scoring system
- Global market comparison table
- Positioning matrix data source
- Content and Hook library
- Strategic trade-off tracker
- Action plan tracker
- Evidence source tracker

### 5.1 When to Generate Excel

Generate an Excel workbook when the user asks for:

- Excel report
- Excel table
- Competitor analysis table
- Competitive strategy workbook
- Scoring workbook
- Benchmark table
- Market comparison table
- Action tracking sheet
- Data table version
- A spreadsheet based on a provided template

If the user uploads an Excel template, preserve the template structure and style as much as possible, then adapt it to the current brand strategy analysis.

### 5.2 Required Excel Sheets

The workbook should include 9 default sheets:

| Sheet Name | Purpose |
|---|---|
| Executive Summary | Strategic conclusion, biggest opportunity, biggest threat, 30-day priorities |
| Competitive Pool | Competitor list, type, category, price band, positioning, reason included |
| 8D Scoring | 8-dimension scoring and overall score |
| Global Market Layer | Market-by-market opportunity and risk comparison |
| Positioning Matrix Data | X/Y coordinates and bubble size used for the positioning map |
| Content & Hook System | Platform, hook, creative format, funnel stage |
| Strategic Trade-Offs | What to learn, adapt, avoid, or hold |
| Action Plan | Priority, team, action, owner, deadline, success metric, status |
| Evidence Sources | Source title, URL, source type, evidence level, notes |

### 5.3 Excel Formatting Requirements

The Excel workbook must be clean, structured, and team-ready.

Required formatting:

1. Freeze header row
2. Enable table filters
3. Use dark header background with white bold text
4. Use brand color for title blocks
5. Apply text wrapping
6. Use readable column widths
7. Use conditional formatting for 1–5 scoring fields
8. Use formulas instead of hardcoded derived metrics
9. Use dropdowns for controlled fields
10. Include Evidence Sources as a separate sheet
11. Include Action Plan as a trackable sheet
12. Keep the workbook ready for monthly review

### 5.4 Required Excel Formulas

In the `8D Scoring` sheet:

```text
Overall Score = AVERAGE(Positioning Clarity : Innovation Strength)
Opportunity Gap = 5 - Overall Score
Threat Level = Overall Score × Target Market Overlap Weight
```

Suggested overlap weights:

```text
High = 3
Medium = 2
Low = 1
```

### 5.5 Required Dropdown Fields

Use dropdowns for:

| Field | Values |
|---|---|
| Type | Subject Brand / Core Competitor / Benchmark Competitor / Potential Competitor / Substitute Competitor / Reference Brand |
| Evidence Level | A / B / C / D / E |
| Priority | High / Medium / Low / Hold |
| Status | Not Started / In Progress / Done / Hold |
| Target Market Overlap | High / Medium / Low |
| Confidence | High / Medium / Low |

### 5.6 Excel Sheet Field Standards

#### Executive Summary

| Field | Description |
|---|---|
| Strategic Conclusion | One-sentence strategic recommendation |
| Because | Core reason |
| Do First | First priority action |
| Do Not Do For Now | Action to avoid |
| Key Metric | Important data point |
| Value | Metric value |
| Meaning | Strategic implication |
| Evidence Level | A / B / C / D / E |

#### Competitive Pool

| Field | Description |
|---|---|
| Brand | Brand name |
| Type | Competitor type |
| Category | Product or business category |
| Main Market | Primary market |
| Price Band | Main price range |
| Target User | Main audience |
| Core Positioning | One-sentence positioning |
| Reason Included | Why this brand is included |
| Threat Type | Price / Product / Brand / Content / Channel / Conversion |
| Evidence Level | A / B / C / D / E |
| Source URL | Source link |

#### 8D Scoring

| Field | Description |
|---|---|
| Brand | Brand name |
| Positioning Clarity | 1–5 score |
| Brand Asset Strength | 1–5 score |
| Product Competitiveness | 1–5 score |
| Content Strength | 1–5 score |
| Channel Strength | 1–5 score |
| Conversion Strength | 1–5 score |
| Reputation Strength | 1–5 score |
| Innovation Strength | 1–5 score |
| Overall Score | Formula |
| Opportunity Gap | Formula |
| Target Market Overlap | High / Medium / Low |
| Threat Level | Formula |
| Confidence | High / Medium / Low |
| Notes | Strategic explanation |

#### Action Plan

| Field | Description |
|---|---|
| Priority | High / Medium / Low / Hold |
| Team | Responsible team |
| Action | Specific action |
| Owner | Responsible person or team |
| Deadline | Due date |
| Success Metric | KPI or measurable outcome |
| Status | Not Started / In Progress / Done / Hold |

---

## 6. Initial Clarification

If the user has not provided enough context, ask only the minimum required questions.

Confirm:

1. Brand name
2. Product category
3. Core SKU or product line
4. Current main market
5. Target market
6. Price band
7. Target user
8. Competitor list, if available
9. Report goal
10. Preferred output format

If the user already provided this information, proceed directly.

---

## 7. Analysis Workflow

### Step 1: Build the Competitive Pool

The competitive pool should usually include 6–10 brands.

| Type | Definition | Recommended Quantity |
|---|---|---:|
| Subject Brand | The user’s brand, used as baseline | 1 |
| Core Competitors | Same category, similar price, same target audience | 2–4 |
| Benchmark Competitors | Category leaders or best-in-class examples | 1–2 |
| Potential Competitors | Adjacent players that may enter the same space | 1–2 |
| Substitute Competitors | Different category but solving similar needs | 1–2 |
| Reference Brands | Non-category brands useful for visual/content inspiration | 0–1 |

For each brand, explain:

- Why it is included
- Which strategic decision it affects
- Whether it is a price threat, product threat, brand threat, content threat, channel threat, or conversion threat

### Step 2: Segment Global Markets

Do not flatten global markets into one broad conclusion. Analyze by market.

Default market table:

| Market | Competitive Status | User Concern | Main Channel | Opportunity | Risk |
|---|---|---|---|---|---|
| United States |  |  |  |  |  |
| Canada |  |  |  |  |  |
| United Kingdom |  |  |  |  |  |
| European Union |  |  |  |  |  |
| Australia |  |  |  |  |  |
| Southeast Asia |  |  |  |  |  |
| Middle East |  |  |  |  |  |

### Step 3: Collect Brand Intelligence

For every brand, collect:

- Brand positioning
- Brand asset strength
- Product and price
- Content strategy
- Channel structure
- Conversion mechanism
- User reputation
- Innovation and momentum

### Step 4: Evidence Level System

Every important judgment must include an evidence level.

| Level | Source Type | Allowed Tone |
|:---:|---|---|
| A | Official website, official announcement, financial report, official price page, user-provided internal data | Direct statement |
| B | Authoritative industry report, public platform data, credible third-party tool | High-probability judgment |
| C | Brokerage report, database estimate, institutional estimate | Estimated / approximately / likely |
| D | Media reports, user reviews, social observations, KOL content | Reported / observed |
| E | AI inference or strategic judgment | Clearly labeled as inference |

### Step 5: 8-Dimension Scoring System

Score the subject brand and every competitor.

| Dimension | Scoring Standard |
|---|---|
| Positioning Clarity | 1 = unclear, 5 = highly clear and differentiated |
| Brand Asset Strength | 1 = weak assets, 5 = highly recognizable and memorable |
| Product Competitiveness | 1 = behind competitors, 5 = category-leading |
| Content Strength | 1 = almost no content engine, 5 = content-driven growth |
| Channel Strength | 1 = single channel, 5 = coordinated multi-channel system |
| Conversion Strength | 1 = broken funnel, 5 = strong conversion system |
| Reputation Strength | 1 = weak or negative reputation, 5 = strong organic advocacy |
| Innovation Strength | 1 = no innovation, 5 = trend-leading innovation |

### Step 6: Strategic Trade-Offs

The report must include a Strategic Trade-Off table.

| Competitor Playbook | Should We Learn From It? | How We Should Adapt It | Why We Should Not Copy Directly |
|---|---|---|---|

### Step 7: Action Plan

Actions must be specific.

Include:

- Owner
- Task
- Deadline
- Success metric
- Priority

---

## 8. Tone of Voice

The report tone must be:

- Direct
- Strategic
- Evidence-based
- Specific
- Clear about uncertainty
- Useful for management decisions

Recommended expressions:

```text
Based on current public evidence, we judge that ______.
From a competitive strategy perspective, the real threat is ______.
This playbook can be adapted, but should not be copied directly because ______.
The current priority is not ______. The current priority is ______.
```

Avoid:

```text
Every brand has its own advantages.
We can learn from all competitors.
The brand should improve content quality.
The brand should strengthen brand building.
The market has large potential.
```

---

## 9. Quality Checklist

Before final output, verify:

### HTML

- [ ] All template brand identifiers removed
- [ ] Complete single-file HTML delivered
- [ ] Full-screen Hero included
- [ ] Fixed glass navigation included
- [ ] Large uppercase editorial typography included
- [ ] Animated metrics included
- [ ] Premium grid cards included
- [ ] Executive Summary cards included
- [ ] Competitive Pool cards included
- [ ] Global Market Layer included
- [ ] 8-Dimension Heatmap included
- [ ] SVG Positioning Matrix included
- [ ] Deep Dive uses click-to-expand / collapse
- [ ] Subject brand Deep Dive open by default
- [ ] Competitor cards collapsed by default
- [ ] Score bars animate
- [ ] Content & Hook System included
- [ ] Strategic Trade-Off table included
- [ ] Action Plan with priority rows included
- [ ] Evidence Sources included
- [ ] “How we win” clearly answered
- [ ] “What not to do” clearly answered
- [ ] 30-day actions are concrete
- [ ] No unsupported absolute claims
- [ ] Suitable for team sharing and management reading

### Excel

When Excel is requested, also verify:

- [ ] Excel workbook created
- [ ] 9 default sheets included
- [ ] Sheet names are clear
- [ ] Header rows frozen
- [ ] Filters enabled
- [ ] Dark header with white bold text applied
- [ ] Brand title blocks applied
- [ ] Text wrapping enabled
- [ ] Readable column widths applied
- [ ] Scoring conditional formatting included
- [ ] Overall Score formula included
- [ ] Opportunity Gap formula included
- [ ] Threat Level formula included
- [ ] Dropdown fields included
- [ ] Evidence Sources sheet included
- [ ] Action Plan sheet included
- [ ] Workbook is readable and team-ready

---

## 10. Final Delivery Requirements

Every use of this skill must deliver:

1. HTML report file
2. One-sentence strategic conclusion
3. 8-dimension scoring heatmap
4. Global market difference table
5. Positioning matrix
6. Collapsible Deep Dive
7. Content & Hook System
8. Strategic Trade-Off table
9. 30-day Action Plan
10. Hold / Do Not Do list
11. Evidence Sources

When Excel is requested, also deliver:

12. Excel companion workbook

The final answer must include:

```text
We should ______.
Because ______.
Do ______ first.
Do not do ______ for now.
```

When both files are delivered, include download links:

```text
Download HTML Report: [file]
Download Excel Workbook: [file]
```

---

# End
