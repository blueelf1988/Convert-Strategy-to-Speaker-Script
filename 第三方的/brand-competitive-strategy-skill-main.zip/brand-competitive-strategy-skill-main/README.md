[README.md](https://github.com/user-attachments/files/29100130/README.md)
# Global Brand Competitive Strategy Skill

A reusable AI Skill for generating premium global brand competitive strategy reports.

This Skill helps brand teams analyze competitors, define market positioning, identify global opportunities, evaluate content and channel strategy, and turn competitive intelligence into clear action plans.

---

## What This Skill Does

This Skill generates a structured **Global Brand Competitive Strategy Report** for any brand, category, or market.

It helps teams answer:

- Which market should we prioritize?
- What positioning should the brand own?
- Which competitors matter most?
- What differentiation should we build?
- What should we do first?
- What should we avoid for now?

The output is not a simple competitor summary. It is a decision-ready strategy report with clear recommendations, evidence levels, scoring, positioning maps, content hooks, strategic trade-offs, and execution plans.

---

## Default Deliverables

By default, the Skill generates a complete single-file HTML report.

When requested, it can also generate an Excel companion workbook.

| Deliverable | Purpose |
|---|---|
| HTML Strategy Report | Management-ready strategy report for reading, sharing, presenting, printing, or exporting to PDF |
| Excel Companion Workbook | Team-ready competitor database, scoring workbook, market tracker, evidence tracker, hook library, and action tracker |

---

## HTML Report Format

The HTML report uses a premium editorial competitive-intelligence style.

Required HTML output elements:

1. **Full-screen Hero**
2. **Fixed glass navigation**
3. **Large uppercase editorial typography**
4. **Animated metrics**
5. **Premium grid cards**
6. **8D scoring heatmap**
7. **SVG positioning matrix**
8. **Collapsible Deep Dive**
9. **Score bar animation**
10. **GSAP scroll animation**
11. **Evidence Sources**
12. **Action Plan with priority rows**

---

## HTML Report Structure

The final HTML report should include:

```text
1. Hero
   - Report name
   - Brand name
   - Category / scenario
   - 3–4 animated headline metrics

2. Executive Summary
   - Competitive landscape
   - Biggest opportunity
   - Biggest threat
   - 30-day priority actions

3. Competitive Pool
   - Competitor cards
   - Type labels
   - Inclusion reason
   - Core positioning
   - Main price band

4. Global Market Layer
   - Market difference table
   - Opportunities and risks by market

5. 8-Dimension Heatmap
   - Subject brand + competitors
   - Overall score
   - Opportunity gap

6. Positioning Map
   - SVG positioning matrix
   - Current position
   - Next position

7. Brand Breakdown / Deep Dive
   - Click-to-expand cards
   - Subject brand open by default
   - Competitors collapsed by default

8. Content & Hook System
   - Platform × Hook × Creative format
   - Reusable content directions

9. Key Findings
   - Competitive landscape
   - Core opportunities
   - Biggest threats

10. Strategic Trade-Offs
   - Learn
   - Adapt carefully
   - Avoid
   - Hold for now

11. Action Plan
   - 30-day high-priority actions
   - 3-month direction
   - Hold / not recommended actions

12. Evidence Sources
   - Source title
   - Source type
   - Evidence level
   - Notes

13. Footer
   - Data cutoff
   - Review monthly
   - Built for Brand Team
```

---

## Excel Workbook Format

The Excel output is a **Competitive Strategy Workbook**, not a plain data table.

It is designed for:

- Competitor tracking
- 8-dimension scoring
- Market comparison
- Positioning matrix data
- Evidence management
- Hook library management
- Strategic trade-off tracking
- Action planning
- Monthly review

---

## Required Excel Sheets

The workbook should include 9 default sheets:

| Sheet Name | Purpose |
|---|---|
| Executive Summary | Strategic conclusion, biggest opportunity, biggest threat, and 30-day priorities |
| Competitive Pool | Competitor list, type, category, price band, positioning, reason included |
| 8D Scoring | 8-dimension scoring and overall score |
| Global Market Layer | Market-by-market opportunity and risk comparison |
| Positioning Matrix Data | X/Y coordinates and bubble size used for the positioning map |
| Content & Hook System | Platforms, hooks, content pillars, creative formats |
| Strategic Trade-Offs | What to learn, adapt, avoid, or hold |
| Action Plan | Owner, action, deadline, metric, status |
| Evidence Sources | Source title, URL, source type, evidence level, notes |

---

## Excel Formatting Standard

The Excel workbook should include:

1. Frozen header rows
2. Enabled table filters
3. Dark header background with white bold text
4. Brand-color title blocks
5. Text wrapping
6. Readable column widths
7. Conditional formatting for 1–5 scoring fields
8. Formulas for derived metrics
9. Dropdown fields for controlled inputs
10. Evidence Sources sheet
11. Action Plan tracking sheet
12. Monthly review-ready structure

---

## Excel Formula Standard

In the `8D Scoring` sheet:

```text
Overall Score = AVERAGE(Positioning Clarity : Innovation Strength)
Opportunity Gap = 5 - Overall Score
Threat Level = Overall Score × Target Market Overlap Weight
```

Suggested overlap weights:

```text
High = 3
Medium = 2
Low = 1
```

---

## Excel Dropdown Fields

| Field | Values |
|---|---|
| Type | Subject Brand / Core Competitor / Benchmark Competitor / Potential Competitor / Substitute Competitor / Reference Brand |
| Evidence Level | A / B / C / D / E |
| Priority | High / Medium / Low / Hold |
| Status | Not Started / In Progress / Done / Hold |
| Target Market Overlap | High / Medium / Low |
| Confidence | High / Medium / Low |

---

## Core Framework

The Skill evaluates each brand across 8 dimensions:

| Dimension | Description |
|---|---|
| Positioning Clarity | How clear and differentiated the brand positioning is |
| Brand Asset Strength | How recognizable and consistent the brand assets are |
| Product Competitiveness | How strong the product offer is versus competitors |
| Content Strength | How well the brand uses content to create demand |
| Channel Strength | How coordinated and diversified the channel system is |
| Conversion Strength | How effectively the brand converts interest into purchase |
| Reputation Strength | How strong user reviews, word of mouth, and advocacy are |
| Innovation Strength | How actively the brand innovates or leads category change |

---

## Evidence Level System

Every important judgment should be labeled with an evidence level.

| Level | Source Type | Allowed Tone |
|:---:|---|---|
| A | Official website, official announcement, financial report, official price page, user-provided internal data | Direct statement |
| B | Authoritative industry report, public platform data, credible third-party tool | High-probability judgment |
| C | Brokerage report, database estimate, institutional estimate | Estimated / approximately / likely |
| D | Media reports, user reviews, social observations, KOL content | Reported / observed |
| E | AI inference or strategic judgment | Clearly labeled as inference |

---

## Use Cases

Use this Skill for:

- Competitive analysis
- Global brand strategy
- Brand positioning
- Market entry strategy
- Category strategy
- Homepage comparison
- Product page conversion audit
- Content and hook strategy
- Paid media creative strategy
- Product portfolio planning
- Channel strategy
- Management presentation
- Team review
- Brand upgrade strategy
- Competitor database creation
- Excel-based scoring and tracking

---

## Example Prompt

```text
Generate a global brand competitive strategy report for [Brand Name].

Category: [Product Category]
Core SKU: [Core Product]
Main market: [Current Market]
Target market: [Target Market]
Price band: [Price Range]
Target user: [Target Audience]

Competitors:
- [Competitor A]
- [Competitor B]
- [Competitor C]

Goal:
We want to clarify brand positioning, understand competitors, identify market opportunities, and create a 30-day action plan.

Output format:
Single-file HTML report + Excel companion workbook.
```

---

## Example Final Strategic Answer

Every report should clearly answer:

```text
We should ______.
Because ______.
Do ______ first.
Do not do ______ for now.
```

Example:

```text
We should own the lightweight, easy-to-use positioning in this category.
Because competitors are over-indexing on either low price or heavy technical features.
Do homepage positioning and product page trust modules first.
Do not enter a long-term price war for now.
```

---

## Repository Structure

Recommended structure:

```text
global-brand-competitive-strategy-skill/
├── README.md
├── SKILL.md
├── LICENSE
├── CHANGELOG.md
├── examples/
│   ├── example-prompt.md
│   └── example-output-outline.md
└── references/
    ├── scoring-framework.md
    ├── evidence-levels.md
    └── positioning-matrix.md
```

---

## Files

| File | Purpose |
|---|---|
| `SKILL.md` | The main Skill definition and workflow |
| `README.md` | Project overview and usage guide |
| `LICENSE` | Open-source license |
| `examples/` | Example prompts and output outlines |
| `references/` | Supporting frameworks and scoring references |

---

## License

MIT License.

You are free to use, modify, and distribute this Skill under the terms of the MIT License.

---

## Notes

This Skill is designed for brand teams, marketing teams, founders, content strategists, e-commerce teams, and global market operators.

It works best when the user provides:

- Brand name
- Product category
- Core products
- Target market
- Price band
- Competitor list
- Analysis goal
- Preferred output format

If this information is missing, ask only the minimum necessary clarification questions before generating the report.
